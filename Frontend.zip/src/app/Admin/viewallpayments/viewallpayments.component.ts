import { Component } from '@angular/core';
import { PaymentService } from '../../service/payment.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-viewallpayments',
  templateUrl: './viewallpayments.component.html',
  styleUrl: './viewallpayments.component.css'
})
export class ViewallpaymentsComponent {
  payment:any;
  constructor(private paymentservice:PaymentService,private router:Router,private activateRoute:ActivatedRoute){}
   
ngOnInit():void{
  this.getAllPayments();
}

getAllPayments():void
{
  this.paymentservice.getAllPayments().subscribe(data=>{
    console.log(data);
    this.payment=data;
  })

}

homepage():void{
  this.router.navigateByUrl("/adminhome");
}
}



