import { Booking } from "./booking"

export class Payment {
    payment_id:number
    amount:number
    //method:string
    nameOnCard:string
    cardNumber:string
    expYear:string
    cvv:string
    paidDate:Date//any
    paidAmount:number;

    booking_id:number;
    booking:Booking
    constructor(payment_id: number,amount:number, nameOnCard: string,
         cardNumber: string, expYear: string, cvv: string, paidDate: Date,paidAmount: number, booking_id:number,booking:Booking)
    {
        this.payment_id = payment_id;
        //this.amount = amount;
        //this.method = method;
        this.nameOnCard = nameOnCard;
        this.cardNumber = cardNumber;
        this.expYear = expYear;
        this.cvv = cvv;
        this.paidDate = paidDate;
        this.paidAmount = paidAmount;
        this.booking = booking;
        
        //this.booking_id=booking_id;
        this.booking_id = booking.booking_id;
        this.amount = booking.amount;
      }
}
