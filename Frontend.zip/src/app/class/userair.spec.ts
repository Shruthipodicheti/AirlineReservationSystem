import { Userair } from './userair';

describe('Userair', () => {
  it('should create an instance', () => {
    expect(new Userair()).toBeTruthy();
  });
});
