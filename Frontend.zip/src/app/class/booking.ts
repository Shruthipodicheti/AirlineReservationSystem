import { Flight } from "./flight";

export class Booking {
    booking_id: number;
    date: Date;
    source: string;
    destination: string;
    passengerName: string;
    passengerAge: number;
    seatsToBook: number;
    amount: number;
    status: string;
    flightId: number;
    flight: Flight;

    constructor(booking_id: number,date: Date,source: string,destination: string,passengerName: string,passengerAge: number,seatsToBook: number,amount: number,status: string,flightId: number,flight: Flight)
    {
      this.booking_id=booking_id;
      this.date=date;
      this.source=source;
      this.destination=destination;
      this.passengerName=passengerName;
      this.passengerAge=passengerAge;
      this.seatsToBook=seatsToBook;
      this.amount=amount;
      this.flightId=flightId;

    }



}
