import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Payment } from '../class/payment';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  addPayment(payment: any, getBookingById: () => void, user: number) {
    throw new Error('Method not implemented.');
  }
  private viewpaybypayidurl = "http://localhost:8080/Payment/findPay";
   
  private viewallpayurl="http://localhost:8080/Payment/viewPay";
  private deletebypayidurl ="http://localhost:8080/Payment/deletePay";
 
  private addpaymenturl = "http://localhost:8080/Payment/addPay";
  
  //private updatePaymenturl="http://localhost:8080/Payment/updatePay";
  
  constructor(private http:HttpClient) { }



//GetpaymentById
getpaymentbyid(paymentid: number):Observable<Payment>  {
  const uidUrl = this.viewpaybypayidurl + "/" + paymentid;
  return this.http.get<Payment>(uidUrl);
}

//Get All Payments
getAllPayments():Observable<any>
{
 return this.http.get(this.viewallpayurl);
}

deletePayment(id: number) {
 
  const httpOptions = {
    headers : new HttpHeaders({
        'Content-Type' : 'application/json',
        'Authorization' : 'auth-token',
        'Access-Control-Allow-Origin' : '*'
    })
  };
  return  this.http.delete<Payment>(`${this.deletebypayidurl}/${id}`,httpOptions);
}


  SavePayment(payment: Payment):Observable<any>
 {
  const bookingId = payment.booking_id;
  const paymenturl=this.addpaymenturl+"/"+bookingId;
   const httpOptions = {
     headers : new HttpHeaders({
         'Content-Type' : 'application/json',
         'Authorization' : 'auth-token',
         'Access-Control-Allow-Origin' : '*'
     })
   };
   return  this.http.post<Payment>(paymenturl,payment,httpOptions);
 }

/*
SavePayment(payment:any,booking_id:number):Observable<any>{
  const headers=new HttpHeaders({'Content-Type': 'application/json'});
  const url=`${this.addpaymenturl}/${booking_id}`;
  return this.http.post(url,payment,{headers});
}
*/
 /*
  addPayment(payment: any, orderId: number, customerId: number): Observable<any> {
  const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  const url = `${this.addpaymenturl}/${orderId}/${customerId}`;
  return this.http.post(url, payment, { headers });
} 
 */

}
