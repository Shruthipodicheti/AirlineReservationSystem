import { Component } from '@angular/core';
import { FlightService } from '../../service/flight.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-viewflight',
  templateUrl: './viewflight.component.html',
  styleUrl: './viewflight.component.css'
})
export class ViewflightComponent {
  flight:any;
  hasSearchName: any;
  searchName: string;
  constructor(private flightService:FlightService,private router:Router,private activeRoute:ActivatedRoute){}
  ngOnInit(): void
  {
    this.activeRoute.paramMap.subscribe(()=>this.getAllFlights());
  }
  getAllFlights()
  {
    this.hasSearchName = this.activeRoute.snapshot.paramMap.has("flightName");
       if(this.hasSearchName)
       {
        this.searchName  = this.activeRoute.snapshot.paramMap.get("flightName");
        console.log(this.searchName)
      this.flightService. getFlightByFlightName(this.searchName).subscribe(data=>{
        console.log(data);
        this.flight= data;
      })
    }
    else{
  
    
    this.flightService.getAllFlights().subscribe(data=>{
      console.log(data);
      this.flight=data;
    });
  }
}

homepage():void{
  this.router.navigateByUrl("/welcomeuser");
}

}


