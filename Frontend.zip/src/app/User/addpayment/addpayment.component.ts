import { Component } from '@angular/core';
import { Payment } from '../../class/payment';
import { Booking } from '../../class/booking';
import { PaymentService } from '../../service/payment.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Flight } from '../../class/flight';
import { BookingService } from '../../service/booking.service';

@Component({
  selector: 'app-addpayment',
  templateUrl: './addpayment.component.html',
  styleUrls: ['./addpayment.component.css']
})
export class AddpaymentComponent {
  
  payment: Payment = new Payment(0,0,"","","","",new Date(),0,0,new Booking(0, new Date(), '', '', '', 0, 0, 0, '', 0,new Flight(0,"","","","","",0,0)));
  booking:Booking;
  booking_id: any;
  amount: number;
  constructor(private paymentService: PaymentService,public router: Router) {}

 
    onSubmit() {
      
        this.paymentService.SavePayment(this.payment).subscribe(data => {
          
          alert("Added Successfully"); // Corrected alert message location
          this.router.navigateByUrl("/viewpayments");
        });
      }

      homepage():void{
        this.router.navigateByUrl("/welcomeuser");
      }
      

     
    }

