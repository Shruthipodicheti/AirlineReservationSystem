import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewuserbookingComponent } from './viewuserbooking.component';

describe('ViewuserbookingComponent', () => {
  let component: ViewuserbookingComponent;
  let fixture: ComponentFixture<ViewuserbookingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewuserbookingComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ViewuserbookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
