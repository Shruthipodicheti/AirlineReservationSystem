import { Component } from '@angular/core';
import { BookingService } from '../../service/booking.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-viewuserbooking',
  templateUrl: './viewuserbooking.component.html',
  styleUrl: './viewuserbooking.component.css'
})
export class ViewuserbookingComponent {
  booking:any;


constructor(private bookingService:BookingService,private router:Router,private activateRoute:ActivatedRoute){}
   
ngOnInit():void{
  this.viewAllBookings();
  
}


viewAllBookings():void
{ 
this.bookingService.viewAllBookings().subscribe(data=>{
  console.log(data);
  this.booking=data;
})
}



SaveBooking():void{
this.router.navigateByUrl("/addBooking");
}



deleteBooking(booking_id:number)
{
console.log(booking_id);
if(confirm("Do you want to delete ?"))
{
this.bookingService.deleteBooking(booking_id).subscribe(data=>{
  console.log(data);
  this.viewAllBookings();
})
}
}


updateBooking(booking_id:number)
{
this.router.navigateByUrl("/updateBooking/"+booking_id);

} 

homepage():void{
  this.router.navigateByUrl("/welcomeuser");
}

pay():void{
  this.router.navigateByUrl("/add_payment/:booking_id");
}
}

