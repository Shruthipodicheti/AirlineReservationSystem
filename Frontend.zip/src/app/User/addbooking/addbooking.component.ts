import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Booking } from '../../class/booking';
import { Flight } from '../../class/flight';
import { BookingService } from '../../service/booking.service';

@Component({
  selector: 'app-addbooking',
  templateUrl: './addbooking.component.html',
  styleUrl: './addbooking.component.css'
})
export class AddbookingComponent {
   
  booking:Booking= new Booking(0, new Date(), '', '', '', 0, 0, 0, '', 0, new Flight(0, '', '', '', '', '', 0,0));
  isEditable:any;
  flightId: number;
  seatsToBook: number;

  constructor(private activeRoute: ActivatedRoute, private http: HttpClient, public router: Router, private bookingservice:BookingService) { }
  
  ngOnInit(): void {
    this.booking
    this.activeRoute.paramMap.subscribe(()=>this.booking);
    this.getBookingById();
  }
  
  
  onSubmit() {
    
    console.log(this.booking);
    
    if (this.isEditable) {
      this.bookingservice.updateBooking(this.booking).subscribe(data => {
        alert("Updated Successfully"); // Corrected alert message location
        this.router.navigateByUrl("/viewuserbookings");
      });
    } else {
      this.bookingservice.SaveBooking(this.booking).subscribe(data => {
        alert("Added Successfully"); // Corrected alert message location
        this.router.navigateByUrl("/viewuserbookings");
      });
    }
  }

  getBookingById() {
    const booking_id=parseFloat(this.activeRoute.snapshot.paramMap.get("booking_id"));
    console.log(booking_id);
    if(booking_id>0){
      this.isEditable=true;
      this.bookingservice.getBookingById(booking_id).subscribe((data: Booking)=>{
        this.booking=data;
        console.log(this.booking)
      })
    }
  }
  
homepage():void{
  this.router.navigateByUrl("/welcomeuser");
}

}



