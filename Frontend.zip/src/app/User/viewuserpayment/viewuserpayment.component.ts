import { Component } from '@angular/core';
import { Admin } from '../../class/admin';
import { PaymentService } from '../../service/payment.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-viewuserpayment',
  templateUrl: './viewuserpayment.component.html',
  styleUrl: './viewuserpayment.component.css'
})
export class ViewuserpaymentComponent {
  payment:any;
  hasSearchId: boolean;
  searchId: number;
  p: number = 1;
  count: number = 5;
    admin: Admin;
  constructor(private PaymentService:PaymentService,public router:Router, private activeRoute:ActivatedRoute) { }
  
    ngOnInit(): void 
        {
          this.activeRoute.paramMap.subscribe(()=>this.admin=JSON.parse(sessionStorage.getItem("admin")))
          this.activeRoute.paramMap.subscribe(()=>this.getAllPayments());
          //this.checkSessionAndNavigate();
        }
        getAllPayments()
      {
        this.hasSearchId = this.activeRoute.snapshot.paramMap.has("payment_id");
           if(this.hasSearchId)
           {this.searchId  = Number(this.activeRoute.snapshot.paramMap.get("payment_id"));
            console.log(this.searchId)
            this.PaymentService.getpaymentbyid(this.searchId).subscribe(data=>{
            console.log(data);
            this.payment= data;
            })
          }
          else{
          this.PaymentService.getAllPayments().subscribe(data=>{
            console.log(data);
            this.payment=data;
          });
        }
      }
  deletePayment(payment_id:number)
  {
  console.log(payment_id);
  if(confirm("Do you want to delete ?"))
  {
  this.PaymentService.deletePayment(payment_id).subscribe(data=>{
    console.log(data);
    this.getAllPayments();
  })
  }
  
  
      
  
  }
  
homepage():void{
  this.router.navigateByUrl("/welcomeuser");
}

}
